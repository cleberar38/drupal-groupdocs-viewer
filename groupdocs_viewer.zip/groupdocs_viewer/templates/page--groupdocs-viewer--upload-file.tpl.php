<?php
/**
 * @file
 * Custom theme implementation to display a Drupal page.
 */
?>
<?php print render($page['content']); ?>

<div id="groupdocsBrowser">
	<div id="groupdocsBrowserInner" >
	</div>
</div>
